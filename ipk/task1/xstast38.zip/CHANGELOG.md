## Implementovaná funkcionalita

 - zpracování argumentů v různém pořadí, tisk nápovědy
 - UDP a TCP komunikace se vstupy a výstupy skriptu podle zadání
 - timeout pro neúspěšnou UDP komunikaci
 - zpracování SIGINT signálu během komunikace

## Známé problémy

 - projekt nebyl testován na Windows, kde pravděpodobně nebude fungovat vzhledem k použití Linux funkcí
